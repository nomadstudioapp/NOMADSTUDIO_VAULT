# Leo in the Village

_Created: 2026-10-19T13:13:53.071672+00:00_

## Models required

| Model file | Used by |
| --- | --- |
| `qwen3vl_8b_int8_convrot.safetensors` | Assist, Edit Qwen 2.1, Smart Object Removal |
| `qwen_image\qwen_image_edit_2511_int8_convrot.safetensors` | Upscale (Qwen 2.1) |
| `qwen_image_2.1_int8_convrot.safetensors` | Assist, Edit Qwen 2.1, Smart Object Removal |

## Steps

### 1. Assist · create

**Prompt:** A cheerful village street festival scene featuring colorful bunting and balloons under a bright azure sky. A boy in a red and green checkered coat and red boots zooms past on a kick scooter, while a brown bear baker in a white apron and chef hat juggles golden croissants nearby. A red fox postman with a bushy tail and blue cap rides a red bicycle. Wide shot, rule of thirds composition. Vivid candy-colored palette with soft clay-like textures. Warm, golden hour sunlight casting gentle shadows. In the style of a high-end 3D animated feature film, whimsical and heartwarming emotional tone.

**Params:** seed `93744387`

![Assist](images/step01_1.png)

### 2. Edit Qwen 2.1 · refine

**Prompt:** Keep the exact same cheerful 3D animated movie style with soft clay-like characters and vivid candy colors, and the exact same characters: the boy in his red and green checkered coat and red boots, the brown bear baker (plain brown fur) in her white apron and chef hat, and the red fox postman (a fox, with snout and bushy tail) with his blue cap and leather satchel. Exactly one of each, no one else. Change the scene completely: we are now indoors, inside the cozy bakery, with a big brick oven glowing orange, wooden shelves full of bread and a flour-dusted counter; no street, no village and no sky visible. The bear baker behind the counter offers the boy a warm loaf, and the fox postman at the door tips his cap holding an envelope.

**Params:** seed `-1`, `13.prompt` = `Keep the exact same cheerful 3D animated movie style with soft clay-like characters and vivid candy colors, and the exact same characters: the boy in his red and green checkered coat and red boots, the brown bear baker (plain brown fur) in her white apron and chef hat, and the red fox postman (a fox, with snout and bushy tail) with his blue cap and leather satchel. Exactly one of each, no one else. Change the scene completely: we are now indoors, inside the cozy bakery, with a big brick oven glowing orange, wooden shelves full of bread and a flour-dusted counter; no street, no village and no sky visible. The bear baker behind the counter offers the boy a warm loaf, and the fox postman at the door tips his cap holding an envelope.`, `15.steps` = `25`, `15.cfg` = `1`, `15.seed` = `842160970`, `6.unet_name` = `qwen_image_2.1_int8_convrot.safetensors`, `3.clip_name` = `qwen3vl_8b_int8_convrot.safetensors`

![Edit Qwen 2.1](images/step02_1.png)

### 3. Upscale (Qwen 2.1) · refine

**Prompt:** upscale with details.

**Params:** seed `-1`, `8.scale_by` = `2`, `13.prompt` = `upscale with details.`, `15.steps` = `4`, `15.cfg` = `1`, `15.seed` = `919817144`, `6.unet_name` = `qwen_image\qwen_image_edit_2511_int8_convrot.safetensors`

![Upscale (Qwen 2.1)](images/step03_1.png)

### 4. Smart Selection · refine

**Prompt:** boy in checkered coat, bear baker, fox postman

**Params:** seed `-1`, `3.text` = `boy in checkered coat, bear baker, fox postman`, `4.threshold` = `0.5`, `4.refine_iterations` = `2`, `4.individual_masks` = `False`, `_postprocess.defringe` = `True`, `_postprocess.defringe_strength` = `4`

![Smart Selection](images/step04_1.png)
![Smart Selection](images/step04_2.png)
![Smart Selection](images/step04_3.png)
![Smart Selection](images/step04_4.png)
![Smart Selection](images/step04_5.png)
![Smart Selection](images/step04_6.png)
![Smart Selection](images/step04_7.png)

### 5. Smart Object Removal · refine

**Prompt:** boy in checkered coat, bear baker, fox postman, loaf of bread, envelope, leather satchel

**Params:** seed `-1`, `240.value` = `boy in checkered coat, bear baker, fox postman, loaf of bread, envelope, leather satchel`, `241.value` = `Fill that area with what was behind it, matching the same lighting, perspective and style as the rest of the photo.`, `99:75.threshold` = `0.5`, `114.expand` = `15`, `99:75.refine_iterations` = `2`, `99:75.individual_masks` = `False`, `15.steps` = `25`, `15.cfg` = `1`, `15.seed` = `777672989`, `6.unet_name` = `qwen_image_2.1_int8_convrot.safetensors`, `3.clip_name` = `qwen3vl_8b_int8_convrot.safetensors`

![Smart Object Removal](images/step05_1.png)

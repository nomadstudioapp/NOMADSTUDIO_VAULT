# Same Character 3 Scenes - 9:16

_Created: 2026-10-16T06:16:07.877955+00:00_

## Models required

| Model file | Used by |
| --- | --- |
| `qwen3vl_8b_int8_convrot.safetensors` | Edit Qwen 2.1 |
| `qwen_image_2.1_int8_convrot.safetensors` | Edit Qwen 2.1 |
| `qwen_image_2.1_turbo_int8_convrot.safetensors` | Edit Qwen 2.1 |

## Steps

### 1. Simple · create

**Prompt:** Cinematic vertical 9:16 portrait of a female sci-fi nomad explorer with silver braided hair, a subtle glowing amber cybernetic mark on her cheek, wearing a weathered white-and-copper exo-jacket, standing on a cliff overlooking a colossal crystalline desert canyon with floating monoliths at golden hour, dramatic volumetric sunlight, ultra-realistic 8k masterpiece

**Params:** seed `1729271049`

![Simple](images/step01_1.png)

### 2. Edit Qwen 2.1 · refine

**Prompt:** Move the exact same female explorer with silver braided hair and white-and-copper exo-jacket into a deep bioluminescent crystal cave on the same planet, glowing cyan and violet crystal formations illuminating her face, keep her facial features and outfit identical

**Params:** seed `-1`, `13.prompt` = `Move the exact same female explorer with silver braided hair and white-and-copper exo-jacket into a deep bioluminescent crystal cave on the same planet, glowing cyan and violet crystal formations illuminating her face, keep her facial features and outfit identical`, `15.cfg` = `1`, `15.seed` = `1052674549`, `15.steps` = `25`, `3.clip_name` = `qwen3vl_8b_int8_convrot.safetensors`, `6.unet_name` = `qwen_image_2.1_int8_convrot.safetensors`

![Edit Qwen 2.1](images/step02_1.png)

### 3. Edit Qwen 2.1 · refine

**Prompt:** Place the exact same female explorer with silver braided hair and white-and-copper exo-jacket at a futuristic nomad outpost market at night under twin moons on the same crystalline planet, warm hanging holographic lanterns and dust in the air, keep her exact face and outfit

**Params:** seed `-1`, `13.prompt` = `Place the exact same female explorer with silver braided hair and white-and-copper exo-jacket at a futuristic nomad outpost market at night under twin moons on the same crystalline planet, warm hanging holographic lanterns and dust in the air, keep her exact face and outfit`, `15.cfg` = `1`, `15.seed` = `815891498`, `15.steps` = `8`, `3.clip_name` = `qwen3vl_8b_int8_convrot.safetensors`, `6.unet_name` = `qwen_image_2.1_turbo_int8_convrot.safetensors`

![Edit Qwen 2.1](images/step03_1.png)
